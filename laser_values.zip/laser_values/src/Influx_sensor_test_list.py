#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
import argparse
from influxdb import InfluxDBClient
import time

user = 'root'
password = 'root'
dbname = 'test_sensor_9'



def callback(msg):
    print len(msg.ranges)
    print msg.time_increment

    getal = list(msg.ranges)
    x = 0
    minimum = 0.0
    maximum = 0.0

    for x in range(0, 1440):
        if getal[x] < minimum:
            minimum = getal[x]

    for x in range(0, 1440):
        if str(getal[x]) == "inf":
            #print "getal"
            getal[x] = 0.0

    for x in range(0, 1440):
        if getal[x] > maximum:
            maximum = getal[x]

    teller = time.strftime("%d/%m/%y") + "T" +time.strftime("%I:%M:%S") + "Z" + str(msg.header.stamp.nsecs) + "N"
    json_body = [
        {
            "measurement": "RPLiDAR_sensor_values",
            "tags": {
                "Sensor": "RPLiDAR A3M1"
            },
            "seq": msg.header.seq,
           "frame_id": msg.header.frame_id,
            "time_frame": teller,
            "fields": {
                "angle_min": msg.angle_min,
                "angle_max": msg.angle_max,
                "angle_increment": msg.angle_increment,
                "time_increment": msg.time_increment,
                "scan_time": msg.scan_time,
                "datasheet_min": msg.range_min,
                "datasheet_max": msg.range_max,
                "range_min": minimum,
                "range_max": maximum,
                "range_0": getal[0],
                "range_89": getal[89],
                "range_179": getal[179],
                "range_269": getal[269],
                "range_359": getal[359],
                "range_539": getal[539],
                "range_719": getal[719],
                "range_899": getal[899],
                "range_1079": getal[1079],
                "range_1259": getal[1259],
                "range_1439": getal[1439]
                #"Intensities": msg.intensities,
            }
        }
    ]

    print("Write points: {0}".format(json_body))
    client.write_points(json_body)
    print("test_5")



def main():

    print("test_3")

    print("Create database: " + dbname)
    client.create_database(dbname)
    print("test_4")

    rospy.init_node('Influx_sensor_values')
    sub = rospy.Subscriber('/scan', LaserScan, callback)
    rospy.spin()




def parse_args():
    """Parse the args."""
    parser = argparse.ArgumentParser(
        description='example code InfluxDB with ROS')

    parser.add_argument('--host', type=str, required=False,
                        default='localhost',
                        help='hostname of InfluxDB http API')

    parser.add_argument('--port', type=int, required=False, default=8086,
                        help='port of InfluxDB http API')

    return parser.parse_args()




if __name__ == '__main__':
    print("test_1")
    args = parse_args()

    client = InfluxDBClient('localhost', 8086, user, password, dbname)

    print("test_2")
    main()
