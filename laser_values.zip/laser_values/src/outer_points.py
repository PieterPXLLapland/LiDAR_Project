#! /usr/bin/env python
 
import rospy
from sensor_msgs.msg import LaserScan
 
def callback(msg):
    print "Point at 1", msg.ranges[0]
    print "Point at 90", msg.ranges[89]
    print "Point at 180", msg.ranges[179]
    print "Point at 270", msg.ranges[269]
    print "Point at 360", msg.ranges[359]
    print "Point at 540", msg.ranges[539]
    print "Point at 720", msg.ranges[719]
    print "Point at 900", msg.ranges[899]
    print "Point at 1080", msg.ranges[1079]
    print "Point at 1260", msg.ranges[1259]
    print "Point at 1440", msg.ranges[1439]
    print "---"
 
rospy.init_node('scan_values')
sub = rospy.Subscriber('/scan', LaserScan, callback)
rospy.spin()

