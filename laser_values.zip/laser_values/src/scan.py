#! /usr/bin/env python
 
import rospy
from sensor_msgs.msg import LaserScan
import time
 
def callback(msg):
    print len(msg.ranges)
    print msg.time_increment
    print msg.header.stamp.secs
    print msg.header.seq
    teller = time.strftime("%d/%m/%y") + "T" +time.strftime("%I:%M:%S") + "Z" + str(msg.header.stamp.nsecs) + "N"
    print msg.header.stamp.nsecs
    print(teller)
 
rospy.init_node('scan_values')
sub = rospy.Subscriber('/scan', LaserScan, callback)
rospy.spin()
