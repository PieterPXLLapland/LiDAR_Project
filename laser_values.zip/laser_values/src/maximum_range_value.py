#! /usr/bin/env python
 
import rospy
from sensor_msgs.msg import LaserScan
 
def callback(msg):
    maximum = 0.0
    x = 0
    getal = list(msg.ranges)

    print "Maximum range value:"

    for x in range(0, 1440):
        if str(getal[x]) == "inf":
            #print "getal"
            getal[x] = 0.0

    for x in range(0, 1440):
        if getal[x] > maximum:
            maximum = getal[x]
    print maximum
 
rospy.init_node('Maximum_values')
sub = rospy.Subscriber('/scan', LaserScan, callback)
rospy.spin()

