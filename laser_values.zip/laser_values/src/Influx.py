#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
import argparse
from influxdb import InfluxDBClient
import time

# Name of the Database
# Username and password
user = 'root'
password = 'root'
dbname = 'RPLiDAR_DB'



def callback(msg):
    # print len(msg.ranges)
    # print msg.time_increment

    getal = list(msg.ranges)
    x = 0
    minimum = 0.0
    maximum = 0.0

    # Gets the minimum detected range
    for x in range(0, 1440):
        if getal[x] < minimum:
            minimum = getal[x]

    # Converts all 'inf' values of ranges to 0.0
    for x in range(0, 1440):
        if str(getal[x]) == "inf":
            #print "getal"
            getal[x] = 0.0

    # Gets the maximum detected range
    for x in range(0, 1440):
        if getal[x] > maximum:
            maximum = getal[x]

    # Time the sensor data was collected
    date_time = time.strftime("%d/%m/%y") + "T" +time.strftime("%I:%M:%S") + "Z" + str(msg.header.stamp.nsecs) + "N"

    # Data sent to the Influx database
    json_body = [
        {
            "measurement": "RPLiDAR_sensor_values",
            "tags": {
                "Sensor": "RPLiDAR A3M1"
            },
            "seq": msg.header.seq,
           "frame_id": msg.header.frame_id,
            "time_frame": date_time,
            "fields": {
                "angle_min": msg.angle_min,
                "angle_max": msg.angle_max,
                "angle_increment": msg.angle_increment,
                "time_increment": msg.time_increment,
                "scan_time": msg.scan_time,
                "datasheet_min": msg.range_min,
                "datasheet_max": msg.range_max,
                "range_min": minimum,
                "range_max": maximum,
                "range_0": getal[0],
                "range_89": getal[89],
                "range_179": getal[179],
                "range_269": getal[269],
                "range_359": getal[359],
                "range_539": getal[539],
                "range_719": getal[719],
                "range_899": getal[899],
                "range_1079": getal[1079],
                "range_1259": getal[1259],
                "range_1439": getal[1439]
            }
        }
    ]

    # print("Write points: {0}".format(json_body))
    # Writes data to the database
    client.write_points(json_body)
    print("Data send")



def main():

    print("Create database: " + dbname)
    # Creates a new database to save data in.
    client.create_database(dbname)

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off
    # The anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously
    rospy.init_node('Influx_sensor_values', anonymous=True)

    # The function subscribes tot the '/scan' topic.
    # When a new message is sent over this topic the fucntion callback will be called.
    # 'LaserScan' is the variable type of the message that will be received.
    sub = rospy.Subscriber('/scan', LaserScan, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()




if __name__ == '__main__':

    client = InfluxDBClient('localhost', 8086, user, password, dbname)

    main()

