#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
import argparse
from influxdb import InfluxDBClient
import time

user = 'root'
password = 'root'
dbname = 'test_sensor_4'



def callback(msg):
    print len(msg.ranges)
    print msg.time_increment
    teller = time.strftime("%d/%m/%y") + "T" +time.strftime("%I:%M:%S") + "Z" + str(msg.header.stamp.nsecs) + "N"
    json_body = [
        {
            "measurement": "RPLiDAR_sensor_values",
            "tags": {
                "Sensor": "RPLiDAR A3M1"
            },
            "seq": msg.header.seq,
           "frame_id": msg.header.frame_id,
            "time_frame": teller,
            "fields": {
                "angle_min": msg.angle_min,
                "angle_max": msg.angle_max,
                "angle_increment": msg.angle_increment,
                "time_increment": msg.time_increment,
                "scan_time": msg.scan_time,
                "range_min": msg.range_min,
                "range_max": msg.range_max,
                #"ranges": list(msg.ranges),
                #"Intensities": msg.intensities,
            }
        }
    ]

    print("Write points: {0}".format(json_body))
    client.write_points(json_body)
    print("test_5")



def main():

    print("test_3")

    print("Create database: " + dbname)
    client.create_database(dbname)
    print("test_4")

    rospy.init_node('Influx_sensor_values')
    sub = rospy.Subscriber('/scan', LaserScan, callback)
    rospy.spin()




def parse_args():
    """Parse the args."""
    parser = argparse.ArgumentParser(
        description='example code InfluxDB with ROS')

    parser.add_argument('--host', type=str, required=False,
                        default='localhost',
                        help='hostname of InfluxDB http API')

    parser.add_argument('--port', type=int, required=False, default=8086,
                        help='port of InfluxDB http API')

    return parser.parse_args()




if __name__ == '__main__':
    print("test_1")
    args = parse_args()

    client = InfluxDBClient('localhost', 8086, user, password, dbname)

    print("test_2")
    main()