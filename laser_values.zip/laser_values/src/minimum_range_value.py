#! /usr/bin/env python
 
import rospy
from sensor_msgs.msg import LaserScan
 
def callback(msg):
    minimum = 25.0
    x = 0
    print "minimum range value:"
    for x in range(0, 1440):
        if msg.ranges[x] < minimum:
            minimum = msg.ranges[x]
    print minimum
 
rospy.init_node('Minimum_values')
sub = rospy.Subscriber('/scan', LaserScan, callback)
rospy.spin()

